window.onload = setTimeout(function(){
    alert('The Ninjas have won!');
}, 13000);

function remove(el) {
    var element = el;
    document.getElementById("leftcont33").remove();
}

var clicks = 319;

function increment(element) {
    clicks += 1;
    document.getElementById("score319").innerHTML = clicks;

}

var clicks1 = 159;

function increment1(element) {
    clicks1 += 1;
    document.getElementById("score159").innerHTML = clicks1;

}
